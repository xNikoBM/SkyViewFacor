# cielo_estructura > 2025-11-17 2:55am
https://universe.roboflow.com/aprendizaje-automatico-9su2p/cielo_estructura-3qm54

Provided by a Roboflow user
License: CC BY 4.0

